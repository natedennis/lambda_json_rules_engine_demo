lambda json-rules-engine example

setup your creds

serverless deploy
