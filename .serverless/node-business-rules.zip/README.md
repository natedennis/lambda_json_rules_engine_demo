lambda json-rules-engine example

setup your creds

serverless deploy


{
    "person": {
        "name":"John Jason", 
        "age": 5,
        "fired": []
    }
}